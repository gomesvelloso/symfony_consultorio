<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/especialidades' => [
            [['_route' => 'app_especialidades_nova', '_controller' => 'App\\Controller\\EspecialidadesController::nova'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_especialidades_buscartodos', '_controller' => 'App\\Controller\\EspecialidadesController::buscarTodos'], null, ['GET' => 0], null, false, false, null],
        ],
        '/medicos' => [
            [['_route' => 'app_medicos_novo', '_controller' => 'App\\Controller\\MedicosController::novo'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_medicos_buscartodos', '_controller' => 'App\\Controller\\MedicosController::buscarTodos'], null, ['GET' => 0], null, false, false, null],
        ],
        '/ola' => [[['_route' => 'app_olamundo_olamundo', '_controller' => 'App\\Controller\\OlaMundoController::olaMundoAction'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/especialidades/([^/]++)(?'
                    .'|(*:69)'
                .')'
                .'|/medicos/([^/]++)(?'
                    .'|(*:97)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        69 => [
            [['_route' => 'app_especialidades_buscarum', '_controller' => 'App\\Controller\\EspecialidadesController::buscarUm'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_especialidades_atualiza', '_controller' => 'App\\Controller\\EspecialidadesController::atualiza'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_especialidades_delete', '_controller' => 'App\\Controller\\EspecialidadesController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        97 => [
            [['_route' => 'app_medicos_buscarum', '_controller' => 'App\\Controller\\MedicosController::buscarUm'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_medicos_atualizar', '_controller' => 'App\\Controller\\MedicosController::atualizar'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_medicos_delete', '_controller' => 'App\\Controller\\MedicosController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
